from django.shortcuts import render
from django.http import HttpResponse
def index(request):
	return HttpResponse("Welcome in SHIVA CONCEPT SOLUTION")


def si(request):
	p=50000
	r=2
	t=2
	si = (p*r*t)/100
	return HttpResponse("Result is "+str(si))




