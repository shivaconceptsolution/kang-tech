from django.shortcuts import render
from django.http import HttpResponse
def index(request):
	return render(request,"sampleapp/index.html")

def indexcode(request):
    s = request.GET["txtname"]
    return HttpResponse(s)	

